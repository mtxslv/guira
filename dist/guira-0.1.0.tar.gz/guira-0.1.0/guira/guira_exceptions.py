from lib2to3.pytree import Base


class SimulatorException(Exception): 
    """Exceptions related to the Simulator.

    Args:
        Exception (class): base class for exception
    """